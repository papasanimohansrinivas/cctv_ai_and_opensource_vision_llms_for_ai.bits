pytorchvideo.models.r2plus1d 
=================================


.. automodule:: pytorchvideo.models.r2plus1d
  :members: